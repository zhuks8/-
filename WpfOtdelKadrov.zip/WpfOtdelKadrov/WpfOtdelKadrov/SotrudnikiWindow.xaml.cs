﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace WpfOtdelKadrov
{
    /// <summary>
    /// Логика взаимодействия для SotrudnikiWindow.xaml
    /// </summary>
    public partial class SotrudnikiWindow : System.Windows.Window
    {
        public List<Сотрудники> userList { get; set; }
        public SotrudnikiWindow()
        {
            InitializeComponent();
            using (var db = new KadriEntities())
            {
                userList = db.Сотрудники.ToList();
                var prep = db.Сотрудники.ToList();
                DaGrid.ItemsSource = prep;
            }          
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DobadlSotrWindow dobadlSotrWindow = new DobadlSotrWindow();
            dobadlSotrWindow.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                Сотрудники users = DaGrid.SelectedItem as Сотрудники;         
                if (users != null)
                {
                    EditSotrudWindow add = new EditSotrudWindow();

                    add.a1.Text = Convert.ToString(users.Фамилия);
                    add.a2.Text = Convert.ToString(users.Имя);
                    add.a3.Text = Convert.ToString(users.Отчество);
                    add.a4.Text = Convert.ToString(users.Должность);
                    add.a5.Text = Convert.ToString(users.Телефон);
                    
                    if (add.ShowDialog() == true)
                    {
                        Сотрудники users1 = db.Сотрудники.Find(users.idSotrudnika);
                        users1.Фамилия = add.a1.Text;
                        users1.Имя = add.a2.Text;
                        users1.Отчество = add.a3.Text;
                        users1.Должность = add.a4.Text;
                        users1.Телефон = add.a5.Text;
                        db.SaveChanges();
                    }
                }
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                var del = (Сотрудники)DaGrid.SelectedItem;
                var usern = db.Сотрудники.FirstOrDefault(u => u.idSotrudnika == del.idSotrudnika);
                db.Сотрудники.Remove(usern);
                db.SaveChanges();
                MessageBox.Show("Запись удалена");
                SotrudnikiWindow sotrudnikiWindow = new SotrudnikiWindow();
                sotrudnikiWindow.Show();
                this.Close();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Excel.Application excel = new Excel.Application();
            excel.Visible = true;
            Workbook workbook = excel.Workbooks.Add(System.Reflection.Missing.Value);
            Worksheet sheet1 = (Worksheet)workbook.Sheets[1];

            for (int j = 0; j < DaGrid.Columns.Count; j++) 
            {
                Range myRange = (Range)sheet1.Cells[1, j + 1];
                sheet1.Cells[1, j + 1].Font.Bold = true; 
                sheet1.Columns[j + 1].ColumnWidth = 15; 
                myRange.Value2 = DaGrid.Columns[j].Header;
            }
            for (int i = 0; i < DaGrid.Columns.Count; i++)
            {
                for (int j = 0; j < DaGrid.Items.Count; j++)
                {
                    TextBlock b = DaGrid.Columns[i].GetCellContent(DaGrid.Items[j]) as TextBlock;
                    Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)sheet1.Cells[j + 2, i + 1];
                    myRange.Value2 = b.Text;
                }
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                DaGrid.ItemsSource = db.Сотрудники.Where(a => a.Фамилия == poisk.Text || a.Имя == poisk.Text || a.Должность == poisk.Text).ToList();
            }     
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {        
            using (var db = new KadriEntities())
            {             
                var prep = db.Сотрудники.ToList();
                DaGrid.ItemsSource = prep;
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                if (filtr.SelectedItem == "All")
                {
                    var prep = db.Сотрудники.ToList();
                    DaGrid.ItemsSource = prep;
                }
                else
                {
                    DaGrid.ItemsSource = db.Сотрудники.Where(a => a.Должность == filtr.SelectedItem).ToList();
                }
            }
        }

        private void poisk_TextChanged(object sender, TextChangedEventArgs e)
        {
            po.IsEnabled = !(poisk.Text.Length < 2);
        }

        private void filtr_Loaded(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                var ListAir = db.Сотрудники.Select(p => p.Должность).ToList();
                ListAir.Insert(0, "All");
                filtr.ItemsSource = ListAir;
            }
        }
    }
}
