﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace WpfOtdelKadrov
{
    /// <summary>
    /// Логика взаимодействия для DobadlSotrWindow.xaml
    /// </summary>
    public partial class DobadlSotrWindow : Window
    {
        public DobadlSotrWindow()
        {
            InitializeComponent();
            if (!(a1.Text.Length < 2)&& !(a2.Text.Length < 2) && !(a3.Text.Length < 2) && !(a4.Text.Length < 0) && !(a5.Text.Length < 11))
            {
                button1.IsEnabled = true;
            }
            else
            {
                button1.IsEnabled = false;
            }   
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                var usern = new Сотрудники();
                usern.Фамилия = a1.Text;
                usern.Имя = a2.Text;
                usern.Отчество = a3.Text;
                usern.Должность = a4.Text;
                usern.Телефон = a5.Text;
                usern.Пол = a9.Text;
                usern.Образование = a6.Text;
                usern.СемейноеПоложение = a7.Text;
                usern.ИНН = a8.Text;
                usern.СерияПаспорта = a11.Text;
                usern.НомерПаспорта = a12.Text;
                usern.Гражданство = a10.Text;
                //usern.Фото = foto;


                db.Сотрудники.Add(usern);
                db.SaveChanges();
                MessageBox.Show("Сотрудник добавлен");
                this.Close();

            }
        }

        private void a1_TextChanged(object sender, TextChangedEventArgs e)
        {
            button1.IsEnabled = !(a1.Text.Length < 2);
        }

        private void a2_TextChanged(object sender, TextChangedEventArgs e)
        {
            button1.IsEnabled = !(a2.Text.Length < 2);
        }

        private void a5_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^0-9]+").IsMatch(e.Text);
        }

        private void a5_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        string imgLokation = "";

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {         
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == true)
            {
                foto.Source = new BitmapImage(new Uri(op.FileName));
                imgLokation = op.FileName.ToString();
                //foto.Stretch= ;

                using (KadriEntities imageEntities = new KadriEntities())
                {
                    Сотрудники imgStore = imageEntities.Сотрудники.Create();

                    //imgStore.Фото = new FileInfo(op.FileName).Name;
                    imageEntities.Сотрудники.Add(imgStore);
                    imageEntities.SaveChanges();
                }
            }
        }
    }
}
