﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfOtdelKadrov
{
    /// <summary>
    /// Логика взаимодействия для bolnicnWindow.xaml
    /// </summary>
    public partial class bolnicnWindow : System.Windows.Window
    {
        public bolnicnWindow()
        {
            InitializeComponent();
            using (var db = new KadriEntities())
            {
                var prep = db.Больничный.ToList();
                DaGrid.ItemsSource = prep;               
            }           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            excel.Visible = true;
            Workbook workbook = excel.Workbooks.Add(System.Reflection.Missing.Value);
            Worksheet sheet1 = (Worksheet)workbook.Sheets[1];

            for (int j = 0; j < DaGrid.Columns.Count; j++)
            {
                Range myRange = (Range)sheet1.Cells[1, j + 1];
                sheet1.Cells[1, j + 1].Font.Bold = true;
                sheet1.Columns[j + 1].ColumnWidth = 15;
                myRange.Value2 = DaGrid.Columns[j].Header;
            }
            for (int i = 0; i < DaGrid.Columns.Count; i++)
            {
                for (int j = 0; j < DaGrid.Items.Count; j++)
                {
                    TextBlock b = DaGrid.Columns[i].GetCellContent(DaGrid.Items[j]) as TextBlock;
                    Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)sheet1.Cells[j + 2, i + 1];
                    myRange.Value2 = b.Text;
                }
            }
        }

        private void Combo_Loaded(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                var ListAir = db.Сотрудники.Select(p => p.Фамилия + " " + p.Имя +" " + p.Отчество).ToList();              
                Combo.ItemsSource = ListAir;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                            
                    var usern = new Больничный();
                    usern.Сотрудник = Combo.Text;
                    usern.ДатаНачала = startD.DisplayDate;
                    usern.ДатаЗавершения = EndD.DisplayDate;
                    usern.Диагноз = a1.Text;

                    db.Больничный.Add(usern);
                    db.SaveChanges();
                    MessageBox.Show("Сотрудник добавлен");
                    var prep = db.Больничный.ToList();
                    DaGrid.ItemsSource = prep;                   

            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                var del = (Больничный)DaGrid.SelectedItem;
                var usern = db.Больничный.FirstOrDefault(u => u.idBolnicni == del.idBolnicni);
                db.Больничный.Remove(usern);
                db.SaveChanges();
                MessageBox.Show("Запись удалена");
                var prep = db.Больничный.ToList();
                DaGrid.ItemsSource = prep;
            }
        }

        private void ComboBox_Loaded(object sender, RoutedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                var ListAir = db.Сотрудники.Select(p => p.Фамилия + " " + p.Имя + " " + p.Отчество).ToList();
                ListAir.Insert(0, "All");
                filtr.ItemsSource = ListAir;
            }
        }
       

        private void filtr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            using (var db = new KadriEntities())
            {
                if (filtr.SelectedItem == "All")
                {
                    var prep = db.Больничный.ToList();
                    DaGrid.ItemsSource = prep;
                }
                else
                {
                    DaGrid.ItemsSource = db.Больничный.Where(a => a.Сотрудник == filtr.SelectedItem).ToList();
                }
            }
        }
    }
}
