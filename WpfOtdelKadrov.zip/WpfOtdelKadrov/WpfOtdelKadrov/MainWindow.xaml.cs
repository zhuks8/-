﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfOtdelKadrov
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var timer = new System.Windows.Threading.DispatcherTimer();
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.IsEnabled = true;
            timer.Tick += (o, t) => { label1.Content = DateTime.Now.ToString(); };
            timer.Start();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using(var db = new KadriEntities())
            {
                var usern = db.Авторизация.FirstOrDefault(uch => uch.Логин == LoginBox.Text && uch.Пароль == PassBox.Password);
                if (usern ==null)
                {
                    MessageBox.Show("Введите верно логин или пароль");
                }
                else
                {
                    OtdelKadrovWindow otdelKadrovWindow = new OtdelKadrovWindow();
                    otdelKadrovWindow.Show();
                    MessageBox.Show("добро пожаловать");
                    this.Close();
                }
            }
        }
    }
}
